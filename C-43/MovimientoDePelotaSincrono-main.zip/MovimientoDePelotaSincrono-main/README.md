# MovimientoSincronoDelaPelota
Movimiento de la pelota de forma síncrona
